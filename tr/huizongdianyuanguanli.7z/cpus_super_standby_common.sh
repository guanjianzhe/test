#!/bin/bash
#macro definition

set -x

TEST_TIMES=$1
SCENE_CHOOSE=$2
LOCK_DIR="/sys/power/wake_lock"
UNLOCK_DIR="/sys/power/wake_unlock"

echo "input para as follow: "
echo total test times == $TEST_TIMES
echo "scene = $SCENE_CHOOSE: "
case $SCENE_CHOOSE in
0) echo do not do extra work when running the test.;;
1) echo usb read and write scene.;;
2) echo sd read and write scene.;;
3) echo video play scene.;;
esac

#need 3 lookup table,for mapping wakeup src, standby period, running period.
#WAKE_UP_SRC means the sequence for select wakeup src from mapping table.
#the same as WAKE_UP_SRC, STANDBY_PERIOD, RUNNING_PERIOD mean the sequence in the lookup table.
WAKE_UP_SRC_TABLE="key"
WAKE_UP_SRC_INDEX="1"
#STANDBY_PERIOD_TABLE="10 150 600 1200 300 600"
#RUNNING_PERIOD_TABLE="30 150 600 1200 300 600"

STANDBY_PERIOD_TABLE="50 105 130 160 120 240"
RUNNING_PERIOD_TABLE="5 15 30 60"

usage()
{
	#show function usage help info
	echo notice: ====== input para err. ======================
	echo need 2 input para, corresponding meaning as follow:
	echo 1st: total test times
	echo 2th: scene.
	echo each test will including: 
	echo different wakeup src, different standby period, different running period.
	echo considering different test condition is necessary for ensure the standby function.
	echo total time for 1 test is: {1st} * {2nd + 3rd}*{3_wakeup_src}*{STANDBY_PERIOD + RUNNING_PERIOD}
	#echo equal: {1st}*{2nd + 3rd}*{3_wakeup_src}*{20 + 30}*3 + 2*{20 + 40 +30} seconds.
	#echo equal: {1st}*{2nd + 3rd}*{150 + 180}
	echo equal: {1st}*{2nd + 3rd}*{wakeup_src}*{20 + 15}*2 + 2*{20 + 15} seconds.
	echo equal: {1st}*{2nd + 3rd}*{140}
	echo assume: 1st = 1, 2nd = 3rd =1, then, the total spend time is: 280/60, about 5min.
	echo exit: =========================================
	return 1
}

set_env()
{
	echo  "install busybox tools"
	#mkdir /data/bbin
	mount -o remount,rw /
	busybox --install -s /sbin
	#export PATH=$PWD:$PATH
	rm -rf /sbin/reboot

	echo none >/sys/power/pm_test
	
	echo "setting console suspend setting value to : "
	backup_console_suspend=$(cat /sys/module/printk/parameters/console_suspend)
	echo N > /sys/module/printk/parameters/console_suspend
	cat /sys/module/printk/parameters/console_suspend
	echo backup_console_suspend equal = $backup_console_suspend

	echo "setting initcall_debug setting value to : "
	backup_initcall_debug=$(cat /sys/module/kernel/parameters/initcall_debug)
	echo Y > /sys/module/kernel/parameters/initcall_debug
	cat /sys/module/kernel/parameters/initcall_debug
	echo backup_initcall_debug = $backup_initcall_debug

	echo "setting loglevel setting value to:  "
	backup_loglevel=$(cat /proc/sys/kernel/printk)
	echo 8 > /proc/sys/kernel/printk
	cat /proc/sys/kernel/printk
	echo backup_loglevel = $backup_loglevel

	backup_time_to_wakeup=$(cat /sys/module/pm_tmp/parameters/time_to_wakeup)
	echo "backup_time_to_wakeup = $backup_time_to_wakeup "
	
	echo start memster
	memtester 100M  &
	memtester 100M  &
	PID1=$!
	echo pid = $PID1
	memtester 50M >>/dev/null &
	PID2=$!
	echo pid = $PID2
	memtester 50M >>/dev/null &
	PID3=$!
	echo pid = $PID3
	memtester 100M >>/dev/null &
	PID4=$!
	echo pid = $PID4
	memtester 150M  &
	memtester 50M  &
	memtester 50M  &
	memtester 50M  &
	
	echo "setting arisc debug_mask setting value to : "
	backup_arisc_debug=$(cat /sys/devices/platform/sunxi-arisc/debug_mask)
	echo 2 > /sys/devices/platform/sunxi-arisc/debug_mask
	cat /sys/devices/platform/sunxi-arisc/debug_mask	
	echo backup_arisc_debug = $backup_arisc_debug
	
	echo "setting for dram crc: 0x40000000 0x1000000"
	echo 1 0x40000000 0x4000000 > /sys/power/aw_ex_standby/dram_crc_paras
	cat /sys/power/aw_ex_standby/dram_crc_paras

}

restore_env()
{
	echo "restore arisc debug_mask setting value. "
	echo $backup_arisc_debug > /sys/devices/platform/sunxi-arisc/debug_mask
	cat /sys/devices/platform/sunxi-arisc/debug_mask	
	
	echo "restore console suspend setting value. "
	echo $backup_console_suspend > /sys/module/printk/parameters/console_suspend
	cat /sys/module/printk/parameters/console_suspend
    
	echo "restore initcall_debug setting value."
	echo $backup_initcall_debug > /sys/module/kernel/parameters/initcall_debug
	cat /sys/module/kernel/parameters/initcall_debug

	echo "restore loglevel setting value. "
	echo $backup_loglevel > /proc/sys/kernel/printk
	cat /proc/sys/kernel/printk
	
	echo "restore the system auto wakeup para. "
	echo $backup_time_to_wakeup > /sys/module/pm_tmp/parameters/time_to_wakeup
	cat /sys/module/pm_tmp/parameters/time_to_wakeup
	
	echo " kill memtest. "
	kill $PID1
	kill $PID2
	kill $PID3
	kill $PID4

}

set_auto_wakeup()
{
	AMPLIFIED_NUM=600
	echo "set the system auto wakeup after $1 seconds. "
	time_to_wakeup=`busybox expr $1 \* $AMPLIFIED_NUM`
	echo "time_to_wakeup = $time_to_wakeup "
	echo $time_to_wakeup > /sys/module/pm_tmp/parameters/time_to_wakeup
	cat /sys/module/pm_tmp/parameters/time_to_wakeup
	echo "+$1" > /sys/class/rtc/rtc0/wakealarm

}

 do_display_test()
{
	echo " start display. "
	./display_framebuffer_pandisplay.sh &
	backup_display_pid=$(ps | grep -v "grep" | grep "display_framebuffer" | busybox awk -F' ' '{print $1}')
	echo "########### backup_display_pid = $backup_display_pid. ##################"
}


 undo_display_test()
{
	echo " kill display. "
	kill $backup_display_pid
}

# para1: event code, 5 mean standby
# para2: action code, wakeup src type, 1:key; 2:ac-in; 3:usb insert.
# para3: delay_time
construct_cmd()
{ 
	CODE=5
	BLANK=" "
	CMD=$CODE$BLANK$1$BLANK$2
	echo "=====Fun=====$CMD========FUNC==================="
	
	echo "use the auto wakeup instead just for convinent. "
	set_auto_wakeup $2
	

}

clear_all_scene_lock()
{
	for TYPE_UNLOCK in $STANDBY_TYPE ; do
		echo $TYPE_UNLOCK >/sys/power/scene_unlock
	done
}

enter_standby()
{
    echo "power down screen.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo mem > /sys/power/state
}

#==========================================main function==========================
if [ $# != 2 ]
then
	usage
	exit 1
else
	echo begin test:  
fi

#just for tips.
echo "\nAll valid choose for wakeup src :\n"
for WAKE_UP_SRC in $WAKE_UP_SRC_TABLE ; do
	echo ${WAKE_UP_SRC}
done

echo "\nAll valid choose for standby period :\n"
for STANDBY_PERIOD in $STANDBY_PERIOD_TABLE ; do
	echo ${STANDBY_PERIOD}
done

echo "\nAll valid choose for running period :\n"
for RUNNING_PERIOD in $RUNNING_PERIOD_TABLE ; do
	echo ${RUNNING_PERIOD}
done

echo  ++++++++set env first.++++++++++++++++++
set_env
#STANDBY_TYPE=$(cat /sys/power/scene_lock |busybox sed 's/\[//g' |busybox sed 's/\]//g')
STANDBY_TYPE="super_standby super_standby super_standby super_standby super_standby"
#STANDBY_TYPE="normal_standby normal_standby normal_standby normal_standby normal_standby"
echo "standby type to test:"
echo $STANDBY_TYPE

echo "choose scene: $SCENE_CHOOSE"	
case $SCENE_CHOOSE in
1) ./usb-cp.sh;;
2) ./sd-cp.sh;;
3) do_display_test;;
esac

i=0
j=0
#find / -name "test"  > ./cpus_standby_working.log &
while [ $i -lt $TEST_TIMES ] ; do
	echo " begin: the total $i cycle times."
	#select wakeup src
	echo "select wakeup src, please. "
	for WAKE_UP_SRC in $WAKE_UP_SRC_INDEX ; do
		echo	" the total $i times, WAKE_UP_SRC: $WAKE_UP_SRC"
	
		#select standby period, unit is seconds.
		echo "select standby period, unit is seconds. "
		for STANDBY_PERIOD in $STANDBY_PERIOD_TABLE ; do
			echo	" the total $i times, WAKE_UP_SRC: $WAKE_UP_SRC"
			echo	" STANDBY_PERIOD: $STANDBY_PERIOD"
				
			#select running period, unit is seconds.
			echo "select running period, unit is seconds. "
			for RUNNING_PERIOD in $RUNNING_PERIOD_TABLE ; do
				echo	" the total $i times, WAKE_UP_SRC: $WAKE_UP_SRC"
				echo	" STANDBY_PERIOD: $STANDBY_PERIOD"
				echo	" RUNNING_PERIOD: $RUNNING_PERIOD"
				
				for TYPE in $STANDBY_TYPE ; do
					echo	" the total $i times, WAKE_UP_SRC: $WAKE_UP_SRC"
					echo	" STANDBY_PERIOD: $STANDBY_PERIOD"
					echo	" RUNNING_PERIOD: $RUNNING_PERIOD"
					echo    " TYPE: $TYPE"
					
					#set scene lock
					clear_all_scene_lock
					echo $TYPE >/sys/power/scene_lock
					echo "testing $TYPE"
				
					#repeat do the inner cycle

					echo for standby test: the inner $j time
					echo running $RUNNING_PERIOD seconds.
					echo "to show kernel timestamp"
					cat /sys/class/rtc/rtc0/time
					sleep $RUNNING_PERIOD
					cat /sys/class/rtc/rtc0/time
					echo running $RUNNING_PERIOD seconds done.
					#notify server to wakeup myself
					#construct command: 
					 construct_cmd $WAKE_UP_SRC $STANDBY_PERIOD
					# echo "=======Debug=======$CMD=======$j=======" 
					# sh $TEST_PATH/common/send_command.sh $CMD
					
					#enter super standby
					enter_standby

					j=$(busybox expr $j + 1)
					echo $j >/data/testcnt

					echo summary begin for the last past standby test...
					echo past inner standby test: $j time
					echo WAKE_UP_SRC    == $WAKE_UP_SRC
					echo STANDBY_PERIOD == $STANDBY_PERIOD
					echo RUNNING_PERIOD == $RUNNING_PERIOD
					echo TYPE == $TYPE
					echo summary done!!!
					
				done
			done
		done
	done
	echo past total cycle test: $i times done.
	i=$(busybox expr $i + 1)
done

echo " end of the test, restore env. "
restore_env
echo "choose scene: $SCENE_CHOOSE"	
case $SCENE_CHOOSE in
1) ./usb-cp.sh;;
2) ./sd-cp.sh;;
3) undo_display_test;;
esac
echo "the test have finished. "


