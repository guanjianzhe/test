#!/bin/bash

#macro definition
TEST_TIMES=$1
INNER_SS_TEST_TIMES=$2
INNER_NS_TEST_TIMES=$3
SCENE_CHOOSE=$4

echo "input para as follow: "
echo total test times == $TEST_TIMES
echo inner super standby test times == $INNER_SS_TEST_TIMES
echo inner normal standby test times == $INNER_NS_TEST_TIMES
echo "scene = $SCENE_CHOOSE: "
case $SCENE_CHOOSE in
0) echo do not do extra work when running the test.;;
1) echo usb read and write scene.;;
2) echo sd read and write scene.;;
3) echo video play scene.;;
esac

#need 3 lookup table,for mapping wakeup src, standby period, running period.
#WAKE_UP_SRC means the sequence for select wakeup src from mapping table.
#the same as WAKE_UP_SRC, STANDBY_PERIOD, RUNNING_PERIOD mean the sequence in the lookup table.
WAKE_UP_SRC_TABLE="key"
WAKE_UP_SRC_INDEX="1"
STANDBY_PERIOD_TABLE="20 15"
RUNNING_PERIOD_TABLE="20 15"

function usage()
{
	#show function usage help info
	echo notice: ====== input para err. ======================
	echo need 4 input para, corresponding meaning as follow:
	echo 1st: total test times
	echo 2nd: inner super standby test times
	echo 3rd: inner normal standby test times
	echo 4th: scene.
	echo each test will including: 
	echo different wakeup src, different standby period, different running period.
	echo considering different test condition is necessary for ensure the standby function.
	echo total time for 1 test is: {1st} * {2nd + 3rd}*{3_wakeup_src}*{STANDBY_PERIOD + RUNNING_PERIOD}
	#echo equal: {1st}*{2nd + 3rd}*{3_wakeup_src}*{20 + 30}*3 + 2*{20 + 40 +30} seconds.
	#echo equal: {1st}*{2nd + 3rd}*{150 + 180}
	echo equal: {1st}*{2nd + 3rd}*{wakeup_src}*{20 + 15}*2 + 2*{20 + 15} seconds.
	echo equal: {1st}*{2nd + 3rd}*{140}
	echo assume: 1st = 1, 2nd = 3rd =1, then, the total spend time is: 280/60, about 5min.
	echo exit: =========================================
	return 1
}

function set_env()
{
	echo "hotplug on all cpu "
	if [ -d /sys/devices/system/cpu/cpu1 ]
	then
	echo 1 > /sys/devices/system/cpu/cpu1/online
	fi
	if [ -d /sys/devices/system/cpu/cpu2 ]
	then
	echo 1 > /sys/devices/system/cpu/cpu2/online
	fi
	if [ -d /sys/devices/system/cpu/cpu3 ]
	then
	echo 1 > /sys/devices/system/cpu/cpu3/online
	fi


	echo "setting console suspend setting value to : "
	backup_console_suspend=$(cat /sys/module/printk/parameters/console_suspend)
	echo N > /sys/module/printk/parameters/console_suspend
	cat /sys/module/printk/parameters/console_suspend
	echo backup_console_suspend equal = $backup_console_suspend

	echo "setting initcall_debug setting value to : "
	backup_initcall_debug=$(cat /sys/module/kernel/parameters/initcall_debug)
	echo Y > /sys/module/kernel/parameters/initcall_debug
	cat /sys/module/kernel/parameters/initcall_debug
	echo backup_initcall_debug = $backup_initcall_debug

	echo "setting loglevel setting value to:  "
	backup_loglevel=$(cat /proc/sys/kernel/printk)
	echo 8 > /proc/sys/kernel/printk
	cat /proc/sys/kernel/printk
	echo backup_loglevel = $backup_loglevel

	backup_time_to_wakeup=$(cat /sys/module/pm_tmp/parameters/time_to_wakeup)
	echo "backup_time_to_wakeup = $backup_time_to_wakeup "
	
	echo "memtester 100M 10& background."
	memtester 40M 10&
	backup_memtest_pid=$(ps | grep -v "grep" | grep "memtester" | awk -F' ' '{print $1}')
	echo "########### backup_memtest_pid = $backup_memtest_pid. ##################"
	
	echo "setting arisc debug_mask setting value to : "
	backup_arisc_debug=$(cat /sys/devices/platform/sunxi-arisc/debug_mask)
	echo 3 > /sys/devices/platform/sunxi-arisc/debug_mask
	cat /sys/devices/platform/sunxi-arisc/debug_mask	
	echo backup_arisc_debug = $backup_arisc_debug

}

function restore_env()
{
	echo "restore arisc debug_mask setting value. "
	echo $backup_arisc_debug > /sys/devices/platform/sunxi-arisc/debug_mask
	cat /sys/devices/platform/sunxi-arisc/debug_mask	
	
	echo "restore console suspend setting value. "
	echo $backup_console_suspend > /sys/module/printk/parameters/console_suspend
	cat /sys/module/printk/parameters/console_suspend
    
	echo "restore initcall_debug setting value."
	echo $backup_initcall_debug > /sys/module/kernel/parameters/initcall_debug
	cat /sys/module/kernel/parameters/initcall_debug

	echo "restore loglevel setting value. "
	echo $backup_loglevel > /proc/sys/kernel/printk
	cat /proc/sys/kernel/printk
	
	echo "restore the system auto wakeup para. "
	echo $backup_time_to_wakeup > /sys/module/pm_tmp/parameters/time_to_wakeup
	cat /sys/module/pm_tmp/parameters/time_to_wakeup
	
	echo " kill memtest. "
	kill $backup_memtest_pid

}

function set_auto_wakeup()
{
	AMPLIFIED_NUM=600
	echo "set the system auto wakeup after $1 seconds. "
	time_to_wakeup=`expr $1 \* $AMPLIFIED_NUM`
	echo "time_to_wakeup = $time_to_wakeup "
	echo $time_to_wakeup > /sys/module/pm_tmp/parameters/time_to_wakeup
	cat /sys/module/pm_tmp/parameters/time_to_wakeup
}

function do_display_test()
{
	echo " start display. "
	./display_framebuffer_pandisplay.sh &
	backup_display_pid=$(ps | grep -v "grep" | grep "display_framebuffer" | awk -F' ' '{print $1}')
	echo "########### backup_display_pid = $backup_display_pid. ##################"
}


function undo_display_test()
{
	echo " kill display. "
	kill $backup_display_pid
}

# para1: event code, 5 mean standby
# para2: action code, wakeup src type, 1:key; 2:ac-in; 3:usb insert.
# para3: delay_time
construct_cmd()
{ 
	CODE=5
	BLANK=" "
	CMD=$CODE$BLANK$1$BLANK$2
	echo "=====Fun=====$CMD========FUNC==================="
	
	echo "use the auto wakeup instead just for convinent. "
	set_auto_wakeup $2

}

#==========================================main function==========================
if [ $# != 4 ]
then
	usage
	exit 1
else
	echo begin test:  
fi

#just for tips.
printf "\nAll valid choose for wakeup src :\n"
for WAKE_UP_SRC in $WAKE_UP_SRC_TABLE ; do
	echo ${WAKE_UP_SRC}
done

printf "\nAll valid choose for standby period :\n"
for STANDBY_PERIOD in $STANDBY_PERIOD_TABLE ; do
	echo ${STANDBY_PERIOD}
done

printf "\nAll valid choose for running period :\n"
for RUNNING_PERIOD in $RUNNING_PERIOD_TABLE ; do
	echo ${RUNNING_PERIOD}
done

echo  ++++++++set env first.++++++++++++++++++
set_env

echo "choose scene: $SCENE_CHOOSE"	
case $SCENE_CHOOSE in
1) ./usb-cp.sh;;
2) ./sd-cp.sh;;
3) do_display_test;;
esac

i=0
j=0
#find / -name "test"  > ./cpus_standby_working.log &
while [ $i -lt $TEST_TIMES ] ; do
	echo " the total $i times."
	#select wakeup src
	echo "select wakeup src, please. "
	for WAKE_UP_SRC in $WAKE_UP_SRC_INDEX ; do
		echo	$WAKE_UP_SRC
	
		#select standby period, unit is seconds.
		echo "select standby period, unit is seconds. "
		for STANDBY_PERIOD in $STANDBY_PERIOD_TABLE ; do
			echo	$STANDBY_PERIOD
				
			#select running period, unit is seconds.
			echo "select running period, unit is seconds. "
			for RUNNING_PERIOD in $RUNNING_PERIOD_TABLE ; do
				echo	$RUNNING_PERIOD
			
				
				#repeat do the inner cycle
				j=0
				while [ $j -lt $INNER_SS_TEST_TIMES ] ; do
					echo for super standby: the inner $j time
					echo running $RUNNING_PERIOD seconds.
					sleep $RUNNING_PERIOD
					#notify server to wakeup myself
					#construct command: 
					 construct_cmd $WAKE_UP_SRC $STANDBY_PERIOD
					# echo "=======Debug=======$CMD=======$j=======" 
					# sh $TEST_PATH/common/send_command.sh $CMD
					
					#enter super standby
					sleep 2
					echo mem > /sys/power/state
					j=$(expr $j + 1)
					i=$(expr $i + 1)
					echo summary for the past standby.
					echo the total test time is: $i time.
					echo past inner super standby, $j time
					echo WAKE_UP_SRC    == $WAKE_UP_SRC
					echo STANDBY_PERIOD == $STANDBY_PERIOD
					echo RUNNING_PERIOD == $RUNNING_PERIOD
					echo summary ended.
				done
				
				#repeat do the inner cycle.
				j=0
				while [ $j -lt $INNER_NS_TEST_TIMES ] ; do
					echo for normal standby: the inner $j time
					sleep $RUNNING_PERIOD
					#notify server to wakeup myself
					#construct command: 
					construct_cmd $WAKE_UP_SRC $STANDBY_PERIOD
					# echo $CMD
					# sh $TEST_PATH/common/send_command.sh $CMD
					
					#enter normal standby
					sleep 2
					echo standby > /sys/power/state
					j=$(expr $j + 1)
					i=$(expr $i + 1)
					echo summary for the past standby.
					echo the total test time is: $i time.
					echo past inner normal standby, $j time
					echo WAKE_UP_SRC    == $WAKE_UP_SRC
					echo STANDBY_PERIOD == $STANDBY_PERIOD
					echo RUNNING_PERIOD == $RUNNING_PERIOD
					echo summary ended.
				done
			done
		done
	done
	echo past total test $i times
done

echo " end of the test, restore env. "
restore_env
echo "choose scene: $SCENE_CHOOSE"	
case $SCENE_CHOOSE in
1) ./usb-cp.sh;;
2) ./sd-cp.sh;;
3) undo_display_test;;
esac
echo "the test have finished. "


