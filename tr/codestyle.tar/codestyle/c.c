#include<stdio.h>
 int a = 3;
int main(void)
{
	int b = 4;
	int c = 3 + 9;
}
