#!/bin/bash

argc=$#

in_cnt=0

for ((i=1;i<=argc;i++)); do
	argv=${!i}
	argv_s1=${argv:0:1}
	argv_s2=${argv:1:1}
	if [ "X_$argv_pre" == "X_-o" ]; then
		output="$output $argv"
		let "i+=1"
		argv_pre=$argv
		continue
	fi
	if [ $argv_s1 != "-" ]; then
		filelist="$filelist $argv"
		let "in_cnt+=1"
	fi
	argv_pre=$argv
done


if [ $in_cnt -gt 1 ] && [ "X_$output" != "X_" ]; then
	echo Not allowed -o option when multi file in.
	exit 1
fi

while true;  do
	read -p "File$filelist will be process, please confirm [y/n]: "
	case $REPLY in
		Y|y)
			echo "Processing $filelist, please waiting..."
			break
			;;
		N|n)
			echo "Cancle, no file will be process."
			exit 1
			;;
		*)
			continue
	esac
done

function del_end_space()
{
	file=$1
	sed -i 's/\s\+$//' $file
}

function del_end_dos()
{
	file=$1
	sed -i 's///'    $file
}

basepath=$(cd `dirname $0`; pwd)
PARAM="-npro -kr -i8 -ts8 -sob -l80 -ss -ncs -cp1"
$basepath/indent $PARAM "$@"

if [ $? -ne 0 ]; then
	exit 1
fi

if [ "X_$output" != "X_" ]; then
	filelist="$output"
fi

for name in `echo $filelist`; do
	del_end_space $name
	del_end_dos   $name
done

echo "Finish Processing."
